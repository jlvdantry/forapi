<?php
class class_men
{
   function menerror($wlmensaje)
   { echo "<center><font color=red size=+2>".$wlmensaje."</font></center>"; }

   function menok($wlmensaje)
   { echo "<center><font color=green size=+2>".$wlmensaje."</font></center>"; }
}
?>
