<?php
function menerror($wlmensaje)
{ echo "<table><th class='menerror'>".$wlmensaje."</th></table>"; }

function menok($wlmensaje)
{ echo "<table><th class='menok'>".$wlmensaje."</th></table>"; }
?>
