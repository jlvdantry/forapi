<?php
echo " <LINK id=estilo REL=StyleSheet HREF='pupanint.css' TYPE='text/css' MEDIA=screen>\n";
echo "<table class=tabletit id=encabezado width=60% align=center>";
echo "<tr align=center>";
echo "<td rowspan=3 width=20%><img src='img/cdmx_03.png' height='65' </td>";
echo "<td><b>Ciudad de Mexico</b></td>";
echo "<td rowspan=3 width=20%><img src='img/styfe.png' height='65' </td>";
echo "<tr align=center>";
echo "<td><b>Secretaria del Trabajo y Fomento al Empleo</b></td>";
echo "</tr>";
echo "<tr align=center>";
echo "<td><b>Secretaria Particular</b></td>";
echo "</tr>";
echo "</table>";
?>
